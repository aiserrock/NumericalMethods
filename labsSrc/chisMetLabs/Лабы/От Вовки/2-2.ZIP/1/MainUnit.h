//---------------------------------------------------------------------------

#ifndef MainUnitH
#define MainUnitH
#include "SHDocVw_OCX.h"
#include <Buttons.hpp>
#include <Chart.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <ExtCtrls.hpp>
#include <jpeg.hpp>
#include <Menus.hpp>
#include <OleCtrls.hpp>
#include <Series.hpp>
#include <StdCtrls.hpp>
#include <TeEngine.hpp>
#include <TeeProcs.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TPanel *PanelFormula;
        TSpeedButton *SPOptions;
        TSpeedButton *SPTask;
        TSpeedButton *SPAbout;
        TMainMenu *MainMenu;
        TMenuItem *N1;
        TMenuItem *N11;
        TMenuItem *N12;
        TMenuItem *N2;
        TMenuItem *N21;
        TMenuItem *N22;
        TPanel *PanelOptions;
        TChart *Chart;
        TGroupBox *GBFunction;
        TLabel *LabelAlpha;
        TLabel *LabelBeta;
        TEdit *EditBeta;
        TEdit *EditGamma;
        TGroupBox *GBField;
        TLabel *LabelC;
        TLabel *LabelB;
        TLabel *LabelA;
        TLabel *LabelD;
        TEdit *EditA;
        TEdit *EditB;
        TEdit *EditC;
        TEdit *EditD;
        TGroupBox *GBOthers;
        TLabel *LabelN;
        TLabel *LabelM;
        TButton *ButtonApply;
        TPanel *PanelAbout;
        TPanel *PanelPhoto;
        TImage *ImagePhoto;
        TLabel *LAboutTitle;
        TMemo *MemoAbout;
        TPanel *PanelTask;
        TLabel *LTaskTitle;
        TCppWebBrowser *CppWebBrowser;
        TEdit *EditM;
        TLabel *LabelP;
        TEdit *EditP;
        TEdit *EditN;
        TLabel *LabelX0;
        TEdit *EditX0;
        TLabel *Label1;
        TPointSeries *Series1;
        void __fastcall OnClick(TObject *Sender);
        void __fastcall FormResize(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall ChartMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall ButtonApplyKeyPress(TObject *Sender, char &Key);
private:	// User declarations
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
        void DrawSeries();
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
